%CURRECT MAPPING %%%%%%%%%%

%GETMAPPING returns a structure containing a mapping table for LBP codes.
%  MAPPING = GETMAPPING(SAMPLES,MAPPINGTYPE) returns a 
%  structure containing a mapping table for
%  LBP codes in a neighbourhood of SAMPLES sampling
%  points. Possible values for MAPPINGTYPE are
%       'u2'   for uniform LBP
%       'ri'   for rotation-invariant LBP
%       'riu2' for uniform rotation-invariant LBP.
%
%  Example:
%       I=imread('rice.tif');
%       MAPPING=getmapping(16,'riu2');
%       LBPHIST=lbp(I,2,16,MAPPING,'hist');
%  Now LBPHIST contains a rotation-invariant uniform LBP
%  histogram in a (16,2) neighbourhood.

% samples:P
% mappingtype: u2, riu2 , ri
function mapping = getmapping(samples,mappingtype)
% Version 0.1.1
% Authors: Marko Heikkil� and Timo Ahonen

% Changelog
% 0.1.1 Changed output to be a structure
% Fixed a bug causing out of memory errors when generating rotation 
% invariant mappings with high number of sampling points.
% Lauge Sorensen is acknowledged for spotting this problem.

table = 0:2^samples-1;
newMax  = 0; %number of patterns in the resulting LBP code
index   = 0;

if strcmp(mappingtype,'u2') %Uniform 2
  newMax = samples*(samples-1) + 3;   %% P=8 -> bins number = 59
  for i = 0:2^samples-1
%     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
    j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
    numt = sum(bitget(bitxor(i,j),1:samples)); %number of 1->0 and
                                               %0->1 transitions
                                               %in binary string 
                                               %x is equal to the
                                               %number of 1-bits in
                                               %XOR(x,Rotate left(x)) 
    if numt <= 2
      table(i+1) = index;
      index = index + 1;
    else
      table(i+1) = newMax - 1;
    end
  end
end


if strcmp(mappingtype,'ri') %Rotation invariant (MinROR)
  tmpMap = zeros(2^samples,1) - 1;  
  for i = 0:2^samples-1
    rm = i;
    r  = i;
    for j = 1:samples-1
%       r = bitset(bitshift(r,1,samples),1,bitget(r,samples)); %rotate
        j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
      if r < rm %find minROR
        rm = r;
      end
    end
    if tmpMap(rm+1) < 0
      tmpMap(rm+1) = newMax;
      newMax = newMax + 1;
    end
    table(i+1) = tmpMap(rm+1);
  end
end

if strcmp(mappingtype,'riu2') %Uniform & Rotation invariant
  newMax = samples + 2;   % P+2 
  
  %why this part required ????
  for i = 0:2^samples - 1
    if(mod(i,100000)==0)
          [ i     2^samples   ]
    end
%     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
    j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left

    numt = sum(bitget(bitxor(i,j),1:samples)); 
    if numt <= 2 % U<=2
      table(i+1) = sum(bitget(i,1:samples)); %count 1s
    else
      table(i+1) = samples+1; % count non-uniform pattern
    end
  end
end

%%
%% new mapping using 3 bins instead of 1 bin for non-uniform pattern
if strcmp(mappingtype,'riu246') %Uniform & Rotation invariant
  newMax = samples + 4;   % P+4 
  
  %why this part required ????
  for i = 0:2^samples - 1
    if(mod(i,100000)==0)
          [ i     2^samples   ]
    end
%     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
      j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
    numt = sum(bitget(bitxor(i,j),1:samples)); 
    if numt <= 2     % U<=2
        table(i+1) = sum(bitget(i,1:samples)); %count 1s
    elseif numt <= 4 % U<=4  
        table(i+1) = samples+1;  % count non-uniform pattern 4>=U>2
    elseif numt <= 6 % U<=6 
        table(i+1) = samples+2;  % count non-uniform pattern 6>=U>4
    else
        table(i+1) = samples+3; % count non-uniform pattern U>=6
    end
    
  end  
end%end riu246

%% new mapping using (3P-3 bins)
% P+1 bins for U<=2 bins:(1 to P+1)th
% P-2 bins for U=4  bins:(P+2 to 2P-1)th
% P-3 bins for U=6  bins:(2P to 3P-4)th
%  1  bin  for U=8  bin :(3P-3)th
if strcmp(mappingtype,'eriu246') %Uniform & Rotation invariant
  newMax =3*samples -6;   % 3P-3   
  %why this part required ????
  for i = 0:2^samples - 1
    OnesCount=sum(bitget(i,1:samples));
    
    if(mod(i,100000)==0)
          [ i     2^samples   ]
    end
   %     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
    j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
    numt = sum(bitget(bitxor(i,j),1:samples)); 
    if numt <= 2     % U<=2
        table(i+1) = OnesCount; %count 1s
    elseif numt <= 4 % U<=4  
        table(i+1) = samples-1+OnesCount;  % count non-uniform pattern 4>=U>2
    elseif numt <= 6 % U<=6 
        table(i+1) = 2*samples-5+OnesCount;  % count non-uniform pattern 6>=U>4
    else             % U>=8
        table(i+1) = 3*samples-7; % count non-uniform pattern U>=6
    end
    
  end  
end%end eriu246
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(mappingtype,'eriu24') %Uniform & Rotation invariant
  newMax =2*samples-1;   % 2P   
  %why this part required ????
  for i = 0:2^samples - 1
    OnesCount=sum(bitget(i,1:samples));
    
    if(mod(i,100000)==0)
          [ i     2^samples   ]
    end
%     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
    j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
    numt = sum(bitget(bitxor(i,j),1:samples)); 
    if numt <= 2     % U<=2
        table(i+1) = OnesCount; %count 1s
    elseif numt <= 4 % U<=4  
        table(i+1) = samples-1+OnesCount;  % count non-uniform pattern 4>=U>2
    else 
        table(i+1) = 2*samples-2;  % count non-uniform pattern U>4   
    end
    
  end  
end%end eriu24
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(mappingtype,'riu4') %Uniform & Rotation invariant
  newMax =samples +2;   % 3P-3   
  %why this part required ????
  for i = 0:2^samples - 1
    OnesCount=sum(bitget(i,1:samples));
    
    if(mod(i,100000)==0)
          [ i     2^samples   ]
    end
   %     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
    j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
    numt = sum(bitget(bitxor(i,j),1:samples)); 
    if numt <= 4     % U<=4
        table(i+1) = OnesCount; %count 1s   
    else             % U>=6
        table(i+1) = 3*samples-7; % count non-uniform pattern U>=6
    end
    
  end  
end%end riu4

%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(mappingtype,'riu6') %Uniform & Rotation invariant
  newMax =samples +2;   %   
  %why this part required ????
  for i = 0:2^samples - 1
    OnesCount=sum(bitget(i,1:samples));
    
    if(mod(i,100000)==0)
          [ i     2^samples   ]
    end
   %     j = bitset(bitshift(i,1,samples),1,bitget(i,samples)); %rotate left
    j = bitset(bitand(bitshift(i,1),2^samples-1),1,bitget(i,samples)); %rotate left
    numt = sum(bitget(bitxor(i,j),1:samples)); 
    if numt <= 6     % U<=6
        table(i+1) = OnesCount; %count 1s   
    else             % U>=8
        table(i+1) = 3*samples-7; % count non-uniform pattern U>=6
    end
    
  end  
end%end riu6

%%%%%%%%%%%%%
mapping.table=table;
mapping.samples=samples;
mapping.num=newMax;
