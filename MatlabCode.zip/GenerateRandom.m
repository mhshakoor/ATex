function [TrainIndex,TestIndex]=GenerateRandom(TrainNumPerClass,PicNumPerClass)

x=1:PicNumPerClass; 
p = randperm(PicNumPerClass);
TrainIndex = p(1:TrainNumPerClass);

for(k=1:numel(TrainIndex))
    x(find(x==TrainIndex(k)))=0;
end
TestIndex=x(find(x~=0));


 