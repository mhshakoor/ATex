% This demo code shows the basic operations of ATex (Artificial Texture)
% This code produce by M.H.Shakoor (mhshakoor@gmail.com)
clc
clear all
close all

classNum = 80; % number of texture classes in  database
PicNumPerClass = 30; %pictire per class

% Radius and Neighborhood
R=1;
P=8*R;

pat='riu2';
patternMapping = getmapping(P,pat);
picCount = 0;   
          
for m=1:classNum    
    strcat(' Processing Class :', num2str(m))
    for n=1:PicNumPerClass         
            filename = sprintf('ATEX\\AtexVGG16\\%d\\%d.png', m,n-1);                
            fid = fopen(filename);
            picCount = picCount+1;
            i=picCount;
            fclose(fid);
            Gray = imread(filename); 
            
            [CLBP_S,CLBP_M,CLBP_C] = clbp(Gray,R,P,patternMapping,'x'); 

             %% noisy texture   
             LBP_SH(i,:) = (hist(CLBP_S(:),0:patternMapping.num-1));  
             LBP_MH(i,:) = (hist(CLBP_M(:),0:patternMapping.num-1));
             
             %% Generate histogram of CLBP_M/C  
             CLBP_MH(i,:) = hist(CLBP_M(:),0:patternMapping.num-1);     
             CLBP_MC = [CLBP_M(:),CLBP_C(:)]; % (n^2)*2 MC LBP codes    
             Hist3D = hist3(CLBP_MC,[patternMapping.num,2]);% 3D MC histogram
             CLBP_MCH(i,:) = reshape(Hist3D,1,numel(Hist3D)); % chnage to vector for save to array    
           
             %%  Generate histogram of CLBP_S/M    
             CLBP_SM = [CLBP_S(:),CLBP_M(:)];  
             Hist3D = hist3(CLBP_SM,[patternMapping.num,patternMapping.num]);
             CLBP_SMH(i,:) = reshape(Hist3D,1,numel(Hist3D)); %make 3D S/M histogram as linear    
    
            %% Generate histogram of CLBP_S/M/C
            CLBP_MCSum = CLBP_M; % LBP code of M
            idx = find(CLBP_C);  % find 1s index  
            CLBP_MCSum(idx) = CLBP_MCSum(idx)+patternMapping.num;  
            CLBP_SMC = [CLBP_S(:),CLBP_MCSum(:)];   
            Hist3D = hist3(CLBP_SMC,[patternMapping.num,patternMapping.num*2]);
            CLBP_SMCH(i,:) = reshape(Hist3D,1,numel(Hist3D)); %make 3D S/M/c histogram as linear   
             
    end
end

TestTimes=10;
for(N=1:TestTimes) 
  strcat('Round :' , num2str(N))
  
  %half of samples is used for train and others for test
  X=PicNumPerClass/2; 
   % generate training and test sets
   TrainNumPerClass = X;  
  [TrainIndex,TestIndex]=GenerateRandom(TrainNumPerClass,PicNumPerClass);
      
  for i=1:classNum 
    trainIDs((i-1)*TrainNumPerClass+1:i*TrainNumPerClass) = TrainIndex+(i-1)*PicNumPerClass;
    trainClassIDs((i-1)*TrainNumPerClass+1:i*TrainNumPerClass) = i;

    testIDs((i-1)*(PicNumPerClass-TrainNumPerClass)+1:i*(PicNumPerClass-TrainNumPerClass)) = TestIndex+(i-1)*PicNumPerClass;
    testClassIDs((i-1)*(PicNumPerClass-TrainNumPerClass)+1:i*(PicNumPerClass-TrainNumPerClass)) = i;
  end


%% CLBP_S RESULTS
trains = LBP_SH(trainIDs,:);
tests = LBP_SH(testIDs,:);
trainNum = size(trains,1);
testNum = size(tests,1);
%P*ImageNum for train (distance matrix)
%each row=a bin of histogram, each col = a train image
DistMat = zeros(P,trainNum); 
% TestImagenumber*TrainImageNumber
DM = zeros(testNum,trainNum);

for i=1:testNum;
    test = tests(i,:);        
    DM(i,:) = distMATChiSquare(trains,test)';
end
CP=ClassifyOnNN(DM,trainClassIDs,testClassIDs);
s='';
s1=sprintf('CLBP_S : %.2f ,  %d', CP);
s=strvcat(s,s1);
rCLBP_S(N,1)=CP;


%% 
%% CLBP_M RESULTS
% classification test using CLBP_M
trains = LBP_MH(trainIDs,:);
tests = LBP_MH(testIDs,:);
trainNum = size(trains,1);
testNum = size(tests,1);
DistMat = zeros(P,trainNum);
DM = zeros(testNum,trainNum);
for i=1:testNum;
    test = tests(i,:);        
    DM(i,:) = distMATChiSquare(trains,test)';
end
% 1-NN classifier using DM(distance) values
CP=ClassifyOnNN(DM,trainClassIDs,testClassIDs);
% sprintf('Accuracy of CLBP_M      on %s : %f', rootpic,CP)
s1=sprintf('CLBP_M : %.2f ,  %d', CP);
s=strvcat(s,s1);
rCLBP_M(N,1)=CP;


%% CLBP_SM RESULTS
% classification test using CLBP_M
trains = CLBP_SMH(trainIDs,:);
tests = CLBP_SMH(testIDs,:);
trainNum = size(trains,1);
testNum = size(tests,1);
DistMat = zeros(P,trainNum);
DM = zeros(testNum,trainNum);
for i=1:testNum;
    test = tests(i,:);        
    DM(i,:) = distMATChiSquare(trains,test)';
end
% 1-NN classifier using DM(distance) values
CP=ClassifyOnNN(DM,trainClassIDs,testClassIDs);
% sprintf('Accuracy of CLBP_M      on %s : %f', rootpic,CP)
s1=sprintf('CLBP_SM : %.2f ,  %d', CP);
s=strvcat(s,s1);
rCLBP_SM(N,1)=CP;


%% CLBP_SMC RESULTS
% classification test using CLBP_M
trains = CLBP_SMCH(trainIDs,:);
tests = CLBP_SMCH(testIDs,:);
trainNum = size(trains,1);
testNum = size(tests,1);
DistMat = zeros(P,trainNum);
DM = zeros(testNum,trainNum);
for i=1:testNum;
    test = tests(i,:);        
    DM(i,:) = distMATChiSquare(trains,test)';
end
% 1-NN classifier using DM(distance) values
CP=ClassifyOnNN(DM,trainClassIDs,testClassIDs);
% sprintf('Accuracy of CLBP_M      on %s : %f', rootpic,CP)
s1=sprintf('CLBP_SMC : %.2f ,  %d', CP);
s=strvcat(s,s1);
rCLBP_SMC(N,1)=CP;


  
end  

TableS=mean(rCLBP_S);
TableM=mean(rCLBP_M);
TableSM=mean(rCLBP_SM);
TableSMC=mean(rCLBP_SMC);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s=sprintf('CLBP  %7s  R=%2d P=%2d     Number of Test:%2d',pat,R,P,TestTimes);
s1=sprintf('CLBP_S    : %8.2f ',TableS);
s=strvcat(s,s1);
s1=sprintf('CLBP_M    : %8.2f',TableM);
s=strvcat(s,s1);
s1=sprintf('CLBP_SM    : %8.2f ',TableSM);
s=strvcat(s,s1);
s1=sprintf('CLBP_SMC    : %8.2f ',TableSMC);
s=strvcat(s,s1);

s
