%  ClassifyOnNN computes the classification accuracy
%  CP=ClassifyOnNN(DM,trainClassIDs,testClassIDs) returns the classification accuracy 
%  The input "DM" is a m*n distance matrix, m is the number of test samples, n is the number of training samples
%  'trainClassIDs' and 'testClassIDs' stores the class ID of training and
%  test samples

function CP=ClassifyOnNN(DM,trainClassIDs,testClassIDs)
% Version 1.0
% Authors: Zhenhua Guo, Lei Zhang and David Zhang
% Copyright @ Biometrics Research Centre, the Hong Kong Polytechnic University

if nargin<3
    disp('Not enough input parameters.')
    return
end

rightCount = 0;
for i=1:length(testClassIDs);
    [distNew, index]= min(DM(i,:));   % find Nearest Neighborhood
    if trainClassIDs(index) == testClassIDs(i)  % judge whether the nearest one is correctly classified
        rightCount = rightCount+1;
    end
end
CP = rightCount/length(testClassIDs)*100;